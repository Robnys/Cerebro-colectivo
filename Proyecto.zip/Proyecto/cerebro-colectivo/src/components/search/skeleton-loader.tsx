'use client'

import { cn } from '@/lib/utils'

interface SkeletonLoaderProps {
  className?: string
  showGraph?: boolean
}

export function SkeletonLoader({ className, showGraph = true }: SkeletonLoaderProps) {
  return (
    <div className={cn("w-full max-w-4xl mx-auto space-y-6", className)}>
      {/* Answer skeleton */}
      <div className="premium-card rounded-2xl p-6 space-y-4">
        {/* Confidence score skeleton */}
        <div className="flex items-center space-x-3">
          <div className="h-2 w-20 bg-muted rounded-full skeleton-shimmer" />
          <div className="h-2 w-16 bg-muted rounded-full skeleton-shimmer" />
        </div>

        {/* Main answer content skeleton */}
        <div className="space-y-3">
          <div className="h-4 bg-muted rounded-lg skeleton-shimmer" />
          <div className="h-4 bg-muted rounded-lg skeleton-shimmer w-5/6" />
          <div className="h-4 bg-muted rounded-lg skeleton-shimmer w-4/5" />
          <div className="h-4 bg-muted rounded-lg skeleton-shimmer w-3/4" />
        </div>

        {/* Response time skeleton */}
        <div className="flex items-center justify-between pt-2">
          <div className="h-2 w-24 bg-muted rounded-full skeleton-shimmer" />
          <div className="h-2 w-20 bg-muted rounded-full skeleton-shimmer" />
        </div>
      </div>

      {/* Knowledge Graph skeleton */}
      {showGraph && (
        <div className="premium-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="h-5 w-32 bg-muted rounded-lg skeleton-shimmer" />
            <div className="h-2 w-24 bg-muted rounded-full skeleton-shimmer" />
          </div>
          
          {/* Graph visualization skeleton */}
          <div className="relative h-48 bg-muted/20 rounded-xl overflow-hidden">
            {/* Node skeletons */}
            <div className="absolute top-8 left-8 w-12 h-12 bg-muted rounded-full skeleton-shimmer animate-pulse-soft" />
            <div className="absolute top-16 right-12 w-10 h-10 bg-muted rounded-full skeleton-shimmer animate-pulse-soft" style={{ animationDelay: '0.2s' }} />
            <div className="absolute bottom-12 left-1/3 w-8 h-8 bg-muted rounded-full skeleton-shimmer animate-pulse-soft" style={{ animationDelay: '0.4s' }} />
            <div className="absolute bottom-8 right-1/4 w-14 h-14 bg-muted rounded-full skeleton-shimmer animate-pulse-soft" style={{ animationDelay: '0.6s' }} />
            
            {/* Edge skeletons */}
            <svg className="absolute inset-0 w-full h-full">
              <line x1="68" y1="56" x2="200" y2="80" className="knowledge-edge stroke-muted" />
              <line x1="68" y1="56" x2="120" y2="150" className="knowledge-edge stroke-muted" />
              <line x1="200" y1="80" x2="250" y2="160" className="knowledge-edge stroke-muted" />
              <line x1="120" y1="150" x2="250" y2="160" className="knowledge-edge stroke-muted" />
            </svg>
          </div>

          {/* Legend skeleton */}
          <div className="flex items-center justify-center space-x-6 mt-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-muted rounded-full skeleton-shimmer" />
              <div className="h-2 w-16 bg-muted rounded-full skeleton-shimmer" />
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-muted rounded-full skeleton-shimmer" />
              <div className="h-2 w-20 bg-muted rounded-full skeleton-shimmer" />
            </div>
          </div>
        </div>
      )}

      {/* Sources skeleton */}
      <div className="premium-card rounded-2xl p-6">
        <div className="h-5 w-24 bg-muted rounded-lg skeleton-shimmer mb-4" />
        
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-start space-x-3 p-3 bg-muted/20 rounded-lg">
              <div className="w-8 h-8 bg-muted rounded-lg skeleton-shimmer flex-shrink-0" />
              <div className="flex-1 space-y-2">
                <div className="h-3 bg-muted rounded skeleton-shimmer w-3/4" />
                <div className="h-2 bg-muted rounded skeleton-shimmer w-full" />
                <div className="h-2 bg-muted rounded skeleton-shimmer w-2/3" />
              </div>
              <div className="h-2 w-16 bg-muted rounded-full skeleton-shimmer flex-shrink-0" />
            </div>
          ))}
        </div>
      </div>

      {/* Share button skeleton */}
      <div className="flex justify-center">
        <div className="h-10 w-32 bg-muted rounded-lg skeleton-shimmer" />
      </div>
    </div>
  )
}
