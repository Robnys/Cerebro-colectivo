'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { Network, Eye, EyeOff, RotateCcw } from 'lucide-react'

interface KnowledgeNode {
  id: string
  type: 'slack' | 'notion' | 'query'
  label: string
  x: number
  y: number
  size: number
  color: string
}

interface KnowledgeEdge {
  from: string
  to: string
  strength: number
}

interface KnowledgeGraphProps {
  sources: Array<{
    document: {
      sourceType: 'SLACK_MESSAGE' | 'NOTION_PAGE'
      metadata: {
        title?: string
        author?: string
        department?: string
      }
    }
    relevanceScore: number
  }>
  query: string
  className?: string
}

export function KnowledgeGraph({ sources, query, className }: KnowledgeGraphProps) {
  const [nodes, setNodes] = useState<KnowledgeNode[]>([])
  const [edges, setEdges] = useState<KnowledgeEdge[]>([])
  const [hoveredNode, setHoveredNode] = useState<string | null>(null)
  const [showLabels, setShowLabels] = useState(true)

  useEffect(() => {
    const graphData = generateGraphData(sources, query)
    setNodes(graphData.nodes)
    setEdges(graphData.edges)
  }, [sources, query])

  const generateGraphData = (sources: any[], query: string) => {
    const nodes: KnowledgeNode[] = []
    const edges: KnowledgeEdge[] = []

    // Add query node (center)
    nodes.push({
      id: 'query',
      type: 'query',
      label: query,
      x: 200,
      y: 150,
      size: 20,
      color: '#8b5cf6'
    })

    // Add source nodes
    sources.forEach((source, index) => {
      const angle = (index * 2 * Math.PI) / sources.length
      const radius = 100
      const x = 200 + radius * Math.cos(angle)
      const y = 150 + radius * Math.sin(angle)

      const nodeType = source.document.sourceType === 'SLACK_MESSAGE' ? 'slack' : 'notion'
      const color = nodeType === 'slack' ? '#10b981' : '#3b82f6'
      const label = source.document.metadata.title || 
                    source.document.metadata.department || 
                    `${nodeType} ${index + 1}`

      nodes.push({
        id: `source-${index}`,
        type: nodeType,
        label: label.length > 20 ? label.slice(0, 20) + '...' : label,
        x,
        y,
        size: 10 + source.relevanceScore * 10,
        color
      })

      // Add edge from query to source
      edges.push({
        from: 'query',
        to: `source-${index}`,
        strength: source.relevanceScore
      })
    })

    return { nodes, edges }
  }

  const getNodeIcon = (type: 'slack' | 'notion' | 'query') => {
    switch (type) {
      case 'slack':
        return '💬'
      case 'notion':
        return '📄'
      case 'query':
        return '🔍'
      default:
        return '📍'
    }
  }

  const resetView = () => {
    setShowLabels(true)
    setHoveredNode(null)
  }

  return (
    <div className={cn("premium-card rounded-2xl p-6", className)}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Network className="h-5 w-5 text-violet-600" />
          <h3 className="text-lg font-semibold text-premium">Conexiones de Conocimiento</h3>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowLabels(!showLabels)}
            className="h-8 w-8 p-0"
          >
            {showLabels ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={resetView}
            className="h-8 w-8 p-0"
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Graph Visualization */}
      <div className="relative h-64 bg-muted/10 rounded-xl overflow-hidden">
        <svg className="absolute inset-0 w-full h-full">
          {/* Edges */}
          {edges.map((edge, index) => {
            const fromNode = nodes.find(n => n.id === edge.from)
            const toNode = nodes.find(n => n.id === edge.to)
            
            if (!fromNode || !toNode) return null
            
            return (
              <line
                key={`edge-${index}`}
                x1={fromNode.x}
                y1={fromNode.y}
                x2={toNode.x}
                y2={toNode.y}
                stroke="#94a3b8"
                strokeWidth={edge.strength * 3}
                strokeOpacity={0.3 + edge.strength * 0.4}
                className="knowledge-edge"
              />
            )
          })}
          
          {/* Nodes */}
          {nodes.map((node) => (
            <g key={node.id}>
              {/* Node circle */}
              <circle
                cx={node.x}
                cy={node.y}
                r={node.size}
                fill={node.color}
                fillOpacity={hoveredNode === node.id ? 1 : 0.8}
                stroke={hoveredNode === node.id ? node.color : 'transparent'}
                strokeWidth={2}
                className={cn(
                  "knowledge-node cursor-pointer transition-all duration-200",
                  hoveredNode === node.id && "animate-knowledge-graph"
                )}
                onMouseEnter={() => setHoveredNode(node.id)}
                onMouseLeave={() => setHoveredNode(null)}
              />
              
              {/* Node icon */}
              <text
                x={node.x}
                y={node.y}
                textAnchor="middle"
                dominantBaseline="middle"
                fontSize={node.size * 0.8}
                className="pointer-events-none select-none"
              >
                {getNodeIcon(node.type)}
              </text>
              
              {/* Node label */}
              {showLabels && (
                <text
                  x={node.x}
                  y={node.y + node.size + 15}
                  textAnchor="middle"
                  fontSize="12"
                  fill="#475569"
                  className="pointer-events-none select-none"
                >
                  {node.label}
                </text>
              )}
            </g>
          ))}
        </svg>

        {/* Hover tooltip */}
        {hoveredNode && (
          <div className="absolute top-4 right-4 premium-card p-3 rounded-lg shadow-lg max-w-xs animate-slide-in-right">
            <div className="text-sm font-medium text-premium">
              {nodes.find(n => n.id === hoveredNode)?.label}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              {nodes.find(n => n.id === hoveredNode)?.type === 'query' 
                ? 'Tu pregunta' 
                : `Fuente: ${nodes.find(n => n.id === hoveredNode)?.type}`
              }
            </div>
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="flex items-center justify-center space-x-6 mt-4">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-violet-600 rounded-full" />
          <span className="text-xs text-muted-foreground">Pregunta</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-green-500 rounded-full" />
          <span className="text-xs text-muted-foreground">Slack</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-blue-500 rounded-full" />
          <span className="text-xs text-muted-foreground">Notion</span>
        </div>
      </div>

      {/* Stats */}
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
        <div className="text-sm text-muted-foreground">
          {sources.length} fuentes conectadas
        </div>
        <div className="text-sm text-muted-foreground">
          Confianza promedio: {(sources.reduce((sum, s) => sum + s.relevanceScore, 0) / sources.length * 100).toFixed(1)}%
        </div>
      </div>
    </div>
  )
}
