'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { Share2, Copy, ExternalLink, Clock, Users, TrendingUp } from 'lucide-react'

interface InsightCardProps {
  query: string
  answer: string
  sources: Array<{
    document: {
      sourceType: 'SLACK_MESSAGE' | 'NOTION_PAGE'
      metadata: {
        title?: string
        author?: string
        department?: string
        url?: string
        channelId?: string
      }
      timestamp: Date
    }
    relevanceScore: number
  }>
  confidence: number
  responseTime: number
  onShare: () => void
  className?: string
}

export function InsightCard({
  query,
  answer,
  sources,
  confidence,
  responseTime,
  onShare,
  className
}: InsightCardProps) {
  const [isSharing, setIsSharing] = useState(false)
  const [copied, setCopied] = useState(false)

  const handleShare = async () => {
    setIsSharing(true)
    await onShare()
    setTimeout(() => setIsSharing(false), 1000)
  }

  const handleCopyLink = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Insight de Cerebro Colectivo',
          text: `Respuesta a: "${query}"`,
          url: window.location.href
        })
      } catch (error) {
        // Fallback to copying
        copyToClipboard()
      }
    } else {
      copyToClipboard()
    }
  }

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      console.error('Failed to copy:', error)
    }
  }

  const formatConfidence = (score: number) => {
    if (score >= 0.8) return { label: 'Alta', color: 'text-green-600', bg: 'bg-green-100' }
    if (score >= 0.6) return { label: 'Media', color: 'text-yellow-600', bg: 'bg-yellow-100' }
    return { label: 'Baja', color: 'text-red-600', bg: 'bg-red-100' }
  }

  const confidenceInfo = formatConfidence(confidence)

  return (
    <div className={cn("premium-card rounded-2xl overflow-hidden", className)}>
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-600 to-indigo-600 p-6 text-white">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h2 className="text-xl font-bold text-premium mb-2">
              {query}
            </h2>
            <div className="flex items-center space-x-4 text-violet-100">
              <div className="flex items-center space-x-1">
                <Clock className="h-4 w-4" />
                <span className="text-sm">{responseTime}ms</span>
              </div>
              <div className="flex items-center space-x-1">
                <TrendingUp className="h-4 w-4" />
                <span className="text-sm">{confidenceInfo.label} confianza</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCopyLink}
              className="text-white hover:bg-white/20 border border-white/20"
            >
              {copied ? <Copy className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={handleShare}
              disabled={isSharing}
              className="text-white hover:bg-white/20 border border-white/20"
            >
              {isSharing ? (
                <div className="animate-spin">
                  <Share2 className="h-4 w-4" />
                </div>
              ) : (
                <Share2 className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Answer */}
      <div className="p-6">
        <div className="prose prose-sm max-w-none">
          <p className="text-gray-800 dark:text-gray-200 leading-relaxed text-premium">
            {answer}
          </p>
        </div>
      </div>

      {/* Sources */}
      <div className="border-t border-border p-6">
        <h3 className="text-sm font-semibold text-muted-foreground mb-4">
          Fuentes ({sources.length})
        </h3>
        
        <div className="space-y-3">
          {sources.slice(0, 3).map((source, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 bg-muted/20 rounded-lg">
              <div className="flex-shrink-0">
                <div className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium",
                  source.document.sourceType === 'SLACK_MESSAGE' 
                    ? "bg-green-100 text-green-600" 
                    : "bg-blue-100 text-blue-600"
                )}>
                  {source.document.sourceType === 'SLACK_MESSAGE' ? '💬' : '📄'}
                </div>
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-medium text-premium truncate">
                    {source.document.metadata.title || 
                     source.document.metadata.department || 
                     `${source.document.sourceType.replace('_', ' ')} ${index + 1}`}
                  </h4>
                  
                  <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                    <span>{(source.relevanceScore * 100).toFixed(0)}%</span>
                    {source.document.metadata.url && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0"
                        onClick={() => window.open(source.document.metadata.url, '_blank')}
                      >
                        <ExternalLink className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center space-x-3 mt-1 text-xs text-muted-foreground">
                  {source.document.metadata.author && (
                    <span>{source.document.metadata.author}</span>
                  )}
                  {source.document.metadata.channelId && (
                    <span>#{source.document.metadata.channelId}</span>
                  )}
                  <span>{new Date(source.document.timestamp).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {sources.length > 3 && (
          <div className="text-center mt-4">
            <Button variant="ghost" size="sm" className="text-muted-foreground">
              Ver {sources.length - 3} fuentes más
            </Button>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="bg-muted/30 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className={cn(
              "px-2 py-1 rounded-full text-xs font-medium",
              confidenceInfo.bg,
              confidenceInfo.color
            )}>
              {confidenceInfo.label} confianza
            </div>
            
            <div className="text-xs text-muted-foreground">
              Generado por Cerebro Colectivo
            </div>
          </div>
          
          <div className="flex items-center space-x-1 text-xs text-muted-foreground">
            <Users className="h-3 w-3" />
            <span>Compartir insight</span>
          </div>
        </div>
      </div>
    </div>
  )
}
