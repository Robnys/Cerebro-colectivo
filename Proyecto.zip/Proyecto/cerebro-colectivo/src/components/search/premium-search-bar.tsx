'use client'

import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import { Search, Sparkles, ArrowRight } from 'lucide-react'

interface PremiumSearchBarProps {
  onSearch: (query: string) => void
  loading?: boolean
  placeholder?: string
  className?: string
}

export function PremiumSearchBar({ 
  onSearch, 
  loading = false, 
  placeholder = "¿Qué necesitas saber ahora?",
  className 
}: PremiumSearchBarProps) {
  const [query, setQuery] = useState('')
  const [isFocused, setIsFocused] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim() && !loading) {
      onSearch(query.trim())
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmit(e as any)
    }
  }

  // Focus search bar on mount
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus()
    }
  }, [])

  return (
    <div className={cn("w-full max-w-3xl mx-auto", className)}>
      <form onSubmit={handleSubmit} className="relative">
        {/* Glow effect container */}
        <div 
          className={cn(
            "search-glow relative rounded-2xl overflow-hidden transition-all duration-300",
            isFocused && "scale-[1.02]"
          )}
        >
          {/* Gradient background */}
          <div className="absolute inset-0 bg-gradient-to-r from-violet-50 via-white to-indigo-50 dark:from-violet-950 dark:via-slate-900 dark:to-indigo-950" />
          
          {/* Search input container */}
          <div className="relative flex items-center px-6 py-4">
            {/* Search icon */}
            <div className="flex items-center justify-center mr-4">
              {loading ? (
                <div className="animate-spin">
                  <Sparkles className="h-5 w-5 text-violet-600" />
                </div>
              ) : (
                <Search className={cn(
                  "h-5 w-5 transition-colors duration-200",
                  isFocused ? "text-violet-600" : "text-muted-foreground"
                )} />
              )}
            </div>

            {/* Main input */}
            <Input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              placeholder={placeholder}
              loading={loading}
              className={cn(
                "flex-1 border-0 bg-transparent text-lg placeholder:text-muted-foreground focus:ring-0 text-premium",
                loading && "animate-pulse-soft"
              )}
              disabled={loading}
            />

            {/* Submit button */}
            <Button
              type="submit"
              disabled={!query.trim() || loading}
              variant="ghost"
              size="icon"
              className={cn(
                "ml-4 rounded-full transition-all duration-200",
                query.trim() && !loading && "bg-violet-600 hover:bg-violet-700 text-white hover:scale-110",
                (!query.trim() || loading) && "opacity-50"
              )}
            >
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>

          {/* Animated border */}
          <div className="absolute inset-0 rounded-2xl border-2 border-transparent bg-gradient-to-r from-violet-600 via-indigo-600 to-violet-600 bg-clip-border opacity-0 transition-opacity duration-300" 
               style={{ 
                 opacity: isFocused ? 1 : 0,
                 backgroundSize: '200% 100%',
                 animation: isFocused ? 'shimmer 3s linear infinite' : 'none'
               }} 
          />
        </div>

        {/* Quick suggestions */}
        {!isFocused && !query && (
          <div className="mt-4 flex flex-wrap gap-2 justify-center animate-fade-in-up">
            {[
              "¿Qué decidimos en la reunión de marketing?",
              "Necesito el roadmap del producto Q1",
              "Quién trabaja en el proyecto X"
            ].map((suggestion, index) => (
              <button
                key={index}
                onClick={() => setQuery(suggestion)}
                className="px-3 py-1 text-sm text-muted-foreground hover:text-foreground hover:bg-muted rounded-full transition-all duration-200 hover:scale-105"
              >
                {suggestion}
              </button>
            ))}
          </div>
        )}

        {/* Loading indicator */}
        {loading && (
          <div className="mt-4 text-center text-sm text-muted-foreground">
            <span className="loading-dots">Buscando en tu conocimiento</span>
          </div>
        )}
      </form>
    </div>
  )
}
