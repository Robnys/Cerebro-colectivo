import { OpenAI } from 'openai'
import { BaseDocument, VectorEmbedding } from '@/types/connectors.types'
import { prisma } from '@/lib/db'

export class VectorizationService {
  private openai: OpenAI
  private readonly EMBEDDING_MODEL = 'text-embedding-3-small'
  private readonly EMBEDDING_DIMENSIONS = 1536
  private readonly BATCH_SIZE = 100

  constructor() {
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    })
  }

  async vectorizeDocuments(documents: BaseDocument[]): Promise<VectorEmbedding[]> {
    const embeddings: VectorEmbedding[] = []

    // Process documents in batches to respect API limits
    for (let i = 0; i < documents.length; i += this.BATCH_SIZE) {
      const batch = documents.slice(i, i + this.BATCH_SIZE)
      
      try {
        const batchEmbeddings = await this.processBatch(batch)
        embeddings.push(...batchEmbeddings)
        
        // Small delay to respect rate limits
        await this.delay(100)
      } catch (error) {
        console.error(`Error processing batch ${i}-${i + this.BATCH_SIZE}:`, error)
      }
    }

    // Store embeddings in database
    await this.storeEmbeddings(embeddings)

    return embeddings
  }

  private async processBatch(documents: BaseDocument[]): Promise<VectorEmbedding[]> {
    // Prepare texts for embedding
    const texts = documents.map(doc => this.prepareTextForEmbedding(doc))
    
    // Get embeddings from OpenAI
    const response = await this.openai.embeddings.create({
      model: this.EMBEDDING_MODEL,
      input: texts,
      dimensions: this.EMBEDDING_DIMENSIONS,
    })

    // Create embedding objects
    return documents.map((doc, index) => ({
      id: `embedding_${doc.id}`,
      sourceType: doc.sourceType,
      sourceId: doc.id,
      embedding: response.data[index].embedding,
      metadata: doc.metadata,
    }))
  }

  private prepareTextForEmbedding(doc: BaseDocument): string {
    // Create a rich text representation for better embeddings
    const parts: string[] = []

    // Add title if available
    if (doc.metadata.title) {
      parts.push(`Title: ${doc.metadata.title}`)
    }

    // Add content
    parts.push(`Content: ${doc.content}`)

    // Add contextual metadata
    if (doc.metadata.author) {
      parts.push(`Author: ${doc.metadata.author}`)
    }

    if (doc.metadata.department) {
      parts.push(`Department: ${doc.metadata.department}`)
    }

    if (doc.metadata.project) {
      parts.push(`Project: ${doc.metadata.project}`)
    }

    if (doc.metadata.tags && doc.metadata.tags.length > 0) {
      parts.push(`Tags: ${doc.metadata.tags.join(', ')}`)
    }

    // Add timestamp context
    const timeAgo = this.getTimeAgo(doc.timestamp)
    parts.push(`Time: ${timeAgo}`)

    return parts.join('\n')
  }

  private getTimeAgo(timestamp: Date): string {
    const now = new Date()
    const diffMs = now.getTime() - timestamp.getTime()
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))

    if (diffDays === 0) return 'today'
    if (diffDays === 1) return 'yesterday'
    if (diffDays < 7) return `${diffDays} days ago`
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`
    if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`
    return `${Math.floor(diffDays / 365)} years ago`
  }

  private async storeEmbeddings(embeddings: VectorEmbedding[]): Promise<void> {
    const operations = embeddings.map(embedding => 
      prisma.vectorEmbedding.upsert({
        where: {
          sourceType_sourceId: {
            sourceType: embedding.sourceType,
            sourceId: embedding.sourceId,
          },
        },
        update: {
          embedding: embedding.embedding,
          metadata: embedding.metadata as any,
        },
        create: {
          sourceType: embedding.sourceType,
          sourceId: embedding.sourceId,
          embedding: embedding.embedding,
          metadata: embedding.metadata as any,
        },
      })
    )

    // Execute all operations in parallel
    await Promise.allSettled(operations)
  }

  async reindexCompany(companyId: string): Promise<void> {
    // Set company context for RLS
    await prisma.$executeRaw`SELECT set_company_context(${companyId}::uuid, ${companyId}::uuid)`

    // Delete existing embeddings for this company
    await prisma.$executeRaw`
      DELETE FROM vector_embeddings 
      WHERE source_id IN (
        SELECT message_id FROM slack_messages WHERE company_id = ${companyId}
        UNION
        SELECT page_id FROM notion_pages WHERE company_id = ${companyId}
      )
    `

    // Get all documents for this company
    const slackMessages = await prisma.slackMessage.findMany({
      where: { companyId },
    })

    const notionPages = await prisma.notionPage.findMany({
      where: { companyId },
    })

    // Convert to BaseDocument format
    const documents: BaseDocument[] = [
      ...slackMessages.map(msg => ({
        id: msg.messageId,
        content: msg.text,
        metadata: {
          author: msg.userId,
          channelId: msg.channelId,
        },
        sourceType: 'SLACK_MESSAGE' as any,
        timestamp: msg.timestamp,
      })),
      ...notionPages.map(page => ({
        id: page.pageId,
        content: page.content,
        metadata: {
          title: page.title,
          url: page.url,
          author: page.createdBy,
        },
        sourceType: 'NOTION_PAGE' as any,
        timestamp: page.lastModified,
      })),
    ]

    // Vectorize all documents
    await this.vectorizeDocuments(documents)
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms))
  }

  async getEmbeddingStats(companyId: string): Promise<{
    totalEmbeddings: number
    slackEmbeddings: number
    notionEmbeddings: number
    lastUpdated: Date | null
  }> {
    await prisma.$executeRaw`SELECT set_company_context(${companyId}::uuid, ${companyId}::uuid)`

    const [stats] = await prisma.$queryRaw`
      SELECT 
        COUNT(*) as total_embeddings,
        COUNT(CASE WHEN source_type = 'SLACK_MESSAGE' THEN 1 END) as slack_embeddings,
        COUNT(CASE WHEN source_type = 'NOTION_PAGE' THEN 1 END) as notion_embeddings,
        MAX(created_at) as last_updated
      FROM vector_embeddings
      WHERE source_id IN (
        SELECT message_id FROM slack_messages WHERE company_id = ${companyId}
        UNION
        SELECT page_id FROM notion_pages WHERE company_id = ${companyId}
      )
    ` as any[]

    return {
      totalEmbeddings: parseInt(stats.total_embeddings),
      slackEmbeddings: parseInt(stats.slack_embeddings),
      notionEmbeddings: parseInt(stats.notion_embeddings),
      lastUpdated: stats.last_updated ? new Date(stats.last_updated) : null,
    }
  }
}
