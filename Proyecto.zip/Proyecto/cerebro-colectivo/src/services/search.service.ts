import { OpenAI } from 'openai'
import { SearchQuery, SearchResult, RAGResponse } from '@/types/connectors.types'
import { prisma } from '@/lib/db'

export class SearchService {
  private openai: OpenAI
  private readonly SEARCH_MODEL = 'gpt-4o'
  private readonly MAX_RESULTS = 10
  private readonly SIMILARITY_THRESHOLD = 0.7

  constructor() {
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    })
  }

  async search(query: SearchQuery): Promise<RAGResponse> {
    const startTime = Date.now()
    
    try {
      // Set company context for Row Level Security
      await prisma.$executeRaw`SELECT set_company_context(${query.companyId}::uuid, ${query.userId}::uuid)`

      // Step 1: Get query embedding
      const queryEmbedding = await this.getQueryEmbedding(query.text)

      // Step 2: Semantic search using pgvector
      const searchResults = await this.semanticSearch(queryEmbedding, query.companyId, query.filters)

      // Step 3: Generate response using RAG
      const response = await this.generateResponse(query.text, searchResults, query.companyId)

      // Step 4: Log search query for analytics
      await this.logSearchQuery(query, searchResults, Date.now() - startTime, response.confidence)

      return {
        answer: response.answer,
        sources: searchResults,
        confidence: response.confidence,
        queryId: response.queryId,
        responseTime: Date.now() - startTime,
      }
    } catch (error) {
      console.error('Search error:', error)
      throw new Error('Search failed')
    }
  }

  private async getQueryEmbedding(queryText: string): Promise<number[]> {
    const response = await this.openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: queryText,
      dimensions: 1536,
    })

    return response.data[0].embedding
  }

  private async semanticSearch(
    queryEmbedding: number[],
    companyId: string,
    filters?: any
  ): Promise<SearchResult[]> {
    // Build the vector similarity search query
    let whereClause = `WHERE source_id IN (
      SELECT message_id FROM slack_messages WHERE company_id = $1
      UNION
      SELECT page_id FROM notion_pages WHERE company_id = $1
    )`

    const params: any[] = [companyId]
    let paramIndex = 2

    // Add filters if provided
    if (filters?.sourceType && filters.sourceType.length > 0) {
      whereClause += ` AND source_type = ANY($${paramIndex})`
      params.push(filters.sourceType)
      paramIndex++
    }

    if (filters?.dateRange) {
      whereClause += ` AND EXISTS (
        SELECT 1 FROM slack_messages sm 
        WHERE sm.message_id = vector_embeddings.source_id 
        AND sm.timestamp >= $${paramIndex} 
        AND sm.timestamp <= $${paramIndex + 1}
        AND sm.company_id = $1
      ) OR EXISTS (
        SELECT 1 FROM notion_pages np 
        WHERE np.page_id = vector_embeddings.source_id 
        AND np.last_modified >= $${paramIndex} 
        AND np.last_modified <= $${paramIndex + 1}
        AND np.company_id = $1
      )`
      params.push(filters.dateRange.start, filters.dateRange.end)
      paramIndex += 2
    }

    const similarityQuery = `
      SELECT 
        source_type,
        source_id,
        metadata,
        1 - (embedding <=> $${paramIndex}::vector) as similarity
      FROM vector_embeddings
      ${whereClause}
      HAVING 1 - (embedding <=> $${paramIndex}::vector) > ${this.SIMILARITY_THRESHOLD}
      ORDER BY similarity DESC
      LIMIT ${this.MAX_RESULTS}
    `

    params.push(`[${queryEmbedding.join(',')}]`)

    const results = await prisma.$queryRawUnsafe(similarityQuery, ...params) as any[]

    // Convert to SearchResult format and get full document details
    const searchResults: SearchResult[] = []

    for (let i = 0; i < results.length; i++) {
      const result = results[i]
      const document = await this.getDocumentDetails(result.source_type, result.source_id)
      
      if (document) {
        searchResults.push({
          document,
          relevanceScore: parseFloat(result.similarity),
          position: i,
        })
      }
    }

    return searchResults
  }

  private async getDocumentDetails(sourceType: string, sourceId: string): Promise<any> {
    try {
      if (sourceType === 'SLACK_MESSAGE') {
        const message = await prisma.slackMessage.findUnique({
          where: { messageId: sourceId },
        })
        
        if (message) {
          return {
            id: message.messageId,
            content: message.text,
            metadata: {
              author: message.userId,
              channelId: message.channelId,
              threadId: message.threadId,
            },
            sourceType: 'SLACK_MESSAGE',
            timestamp: message.timestamp,
          }
        }
      } else if (sourceType === 'NOTION_PAGE') {
        const page = await prisma.notionPage.findUnique({
          where: { pageId: sourceId },
        })
        
        if (page) {
          return {
            id: page.pageId,
            content: page.content,
            metadata: {
              title: page.title,
              url: page.url,
              author: page.createdBy,
            },
            sourceType: 'NOTION_PAGE',
            timestamp: page.lastModified,
          }
        }
      }
    } catch (error) {
      console.error(`Error getting document details for ${sourceType}:${sourceId}:`, error)
    }

    return null
  }

  private async generateResponse(
    queryText: string,
    searchResults: SearchResult[],
    companyId: string
  ): Promise<{ answer: string; confidence: number; queryId: string }> {
    if (searchResults.length === 0) {
      return {
        answer: "No encontré información relevante para tu pregunta. Intenta reformularla o verifica si la información existe en tus canales de Slack o páginas de Notion.",
        confidence: 0.1,
        queryId: `query_${Date.now()}`,
      }
    }

    // Build context from search results
    const context = this.buildContext(searchResults)

    // Generate response with strict context adherence
    const systemPrompt = this.buildSystemPrompt(companyId)
    const userPrompt = this.buildUserPrompt(queryText, context)

    const response = await this.openai.chat.completions.create({
      model: this.SEARCH_MODEL,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: 0.1, // Low temperature for factual responses
      max_tokens: 1000,
    })

    const answer = response.choices[0]?.message?.content || 'No se pudo generar una respuesta.'
    const confidence = this.calculateConfidence(searchResults, answer)

    return {
      answer,
      confidence,
      queryId: `query_${Date.now()}`,
    }
  }

  private buildContext(searchResults: SearchResult[]): string {
    return searchResults
      .slice(0, 5) // Use top 5 results for context
      .map((result, index) => {
        const { document, relevanceScore } = result
        const source = document.sourceType === 'SLACK_MESSAGE' ? 'Slack' : 'Notion'
        const timeAgo = this.getTimeAgo(document.timestamp)
        
        return `[${index + 1}] ${source} (${timeAgo}, confianza: ${(relevanceScore * 100).toFixed(1)}%):
${document.metadata.title ? `Título: ${document.metadata.title}\n` : ''}
${document.content}

Fuente: ${document.metadata.url || `Canal: ${document.metadata.channelId || 'desconocido'}`}
Autor: ${document.metadata.author || 'desconocido'}`
      })
      .join('\n\n---\n\n')
  }

  private buildSystemPrompt(companyId: string): string {
    return `Eres un asistente de conocimiento experto que ayuda a encontrar información dentro de una empresa.

REGLAS CRÍTICAS:
1. SOLO usa la información proporcionada en el contexto. NUNCA inventes información.
2. Si la información no está en el contexto, di claramente "No encontré esa información específica".
3. Si la información es parcial o limitada, indica las limitaciones.
4. Responde de forma concisa y directa.
5. Siempre menciona las fuentes específicas de tu respuesta.
6. La información está limitada a la compañía ID: ${companyId} - nunca references información de otras compañías.

CONTEXTO DE SEGURIDAD:
- Estás trabajando con información confidencial de una empresa específica
- No compartas información con usuarios no autorizados
- Mantén el contexto dentro de la compañía especificada`
  }

  private buildUserPrompt(queryText: string, context: string): string {
    return `Pregunta: ${queryText}

Contexto disponible:
${context}

Basado ÚNICAMENTE en el contexto proporcionado, responde a la pregunta. Si el contexto no contiene suficiente información, indícalo claramente.`
  }

  private calculateConfidence(searchResults: SearchResult[], answer: string): number {
    // Base confidence from search results
    const avgRelevance = searchResults.reduce((sum, result) => sum + result.relevanceScore, 0) / searchResults.length
    
    // Adjust based on answer quality indicators
    let confidence = avgRelevance
    
    // Penalize answers that indicate uncertainty
    if (answer.includes('no encontré') || answer.includes('no tengo información')) {
      confidence *= 0.3
    }
    
    // Boost confidence for answers with specific citations
    if (answer.includes('Según') || answer.includes('Fuente:') || answer.includes('basado en')) {
      confidence *= 1.2
    }
    
    return Math.min(Math.max(confidence, 0), 1)
  }

  private getTimeAgo(timestamp: Date): string {
    const now = new Date()
    const diffMs = now.getTime() - timestamp.getTime()
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))

    if (diffDays === 0) return 'hoy'
    if (diffDays === 1) return 'ayer'
    if (diffDays < 7) return `hace ${diffDays} días`
    if (diffDays < 30) return `hace ${Math.floor(diffDays / 7)} semanas`
    if (diffDays < 365) return `hace ${Math.floor(diffDays / 30)} meses`
    return `hace ${Math.floor(diffDays / 365)} años`
  }

  private async logSearchQuery(
    query: SearchQuery,
    results: SearchResult[],
    responseTime: number,
    confidence: number
  ): Promise<void> {
    try {
      const searchQuery = await prisma.searchQuery.create({
        data: {
          userId: query.userId,
          query: query.text,
          resultsCount: results.length,
          responseTime,
          confidenceScore: confidence,
        },
      })

      // Log knowledge hits for analytics
      const knowledgeHits = results.map((result, index) => ({
        queryId: searchQuery.id,
        sourceType: result.document.sourceType,
        sourceId: result.document.id,
        relevanceScore: result.relevanceScore,
        position: index,
      }))

      await prisma.knowledgeHit.createMany({
        data: knowledgeHits,
      })
    } catch (error) {
      console.error('Error logging search query:', error)
    }
  }

  async getSearchStats(companyId: string, days: number = 30): Promise<{
    totalQueries: number
    avgResponseTime: number
    avgConfidence: number
    topQueries: Array<{ query: string; count: number }>
    sourceDistribution: Array<{ sourceType: string; count: number }>
  }> {
    await prisma.$executeRaw`SELECT set_company_context(${companyId}::uuid, ${companyId}::uuid)`

    const stats = await prisma.$queryRaw`
      SELECT 
        COUNT(*) as total_queries,
        AVG(response_time) as avg_response_time,
        AVG(confidence_score) as avg_confidence
      FROM search_queries 
      WHERE created_at >= NOW() - INTERVAL '${days} days'
    ` as any[]

    const topQueries = await prisma.$queryRaw`
      SELECT query, COUNT(*) as count
      FROM search_queries 
      WHERE created_at >= NOW() - INTERVAL '${days} days'
      GROUP BY query
      ORDER BY count DESC
      LIMIT 10
    ` as any[]

    const sourceDistribution = await prisma.$queryRaw`
      SELECT 
        ve.source_type,
        COUNT(*) as count
      FROM knowledge_hits kh
      JOIN vector_embeddings ve ON kh.source_id = ve.source_id AND kh.source_type = ve.source_type
      JOIN search_queries sq ON kh.query_id = sq.id
      WHERE sq.created_at >= NOW() - INTERVAL '${days} days'
      GROUP BY ve.source_type
    ` as any[]

    return {
      totalQueries: parseInt(stats[0]?.total_queries || 0),
      avgResponseTime: parseFloat(stats[0]?.avg_response_time || 0),
      avgConfidence: parseFloat(stats[0]?.avg_confidence || 0),
      topQueries: topQueries.map(q => ({ query: q.query, count: parseInt(q.count) })),
      sourceDistribution: sourceDistribution.map(s => ({ sourceType: s.source_type, count: parseInt(s.count) })),
    }
  }
}
