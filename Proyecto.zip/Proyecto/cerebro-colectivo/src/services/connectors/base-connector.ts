import { BaseDocument, ConnectorConfig, IngestionResult, DocumentMetadata } from '@/types/connectors.types'

export abstract class BaseConnector {
  protected config: ConnectorConfig

  constructor(config: ConnectorConfig) {
    this.config = config
  }

  abstract ingest(): Promise<IngestionResult>
  abstract validateCredentials(): Promise<boolean>

  protected cleanText(text: string): string {
    return text
      // Remove excessive whitespace
      .replace(/\s+/g, ' ')
      // Remove common noise patterns
      .replace(/[\u0000-\u001F\u007F-\u009F]/g, '')
      // Normalize line breaks
      .replace(/\n\s*\n/g, '\n')
      // Trim whitespace
      .trim()
  }

  protected extractMetadata(raw: any): DocumentMetadata {
    const metadata: DocumentMetadata = {}

    if (raw.title) metadata.title = raw.title
    if (raw.author) metadata.author = raw.author
    if (raw.channelId) metadata.channelId = raw.channelId
    if (raw.threadId) metadata.threadId = raw.threadId
    if (raw.url) metadata.url = raw.url
    if (raw.tags) metadata.tags = Array.isArray(raw.tags) ? raw.tags : [raw.tags]
    if (raw.department) metadata.department = raw.department
    if (raw.project) metadata.project = raw.project

    return metadata
  }

  protected createDocument(
    id: string,
    content: string,
    metadata: DocumentMetadata,
    sourceType: string,
    timestamp: Date
  ): BaseDocument {
    return {
      id,
      content: this.cleanText(content),
      metadata,
      sourceType: sourceType as any,
      timestamp,
    }
  }

  protected async processBatch<T, R>(
    items: T[],
    processor: (item: T) => Promise<R>,
    batchSize: number = 50
  ): Promise<R[]> {
    const results: R[] = []
    
    for (let i = 0; i < items.length; i += batchSize) {
      const batch = items.slice(i, i + batchSize)
      const batchResults = await Promise.allSettled(
        batch.map(processor)
      )
      
      batchResults.forEach((result) => {
        if (result.status === 'fulfilled') {
          results.push(result.value)
        }
      })
    }
    
    return results
  }
}
