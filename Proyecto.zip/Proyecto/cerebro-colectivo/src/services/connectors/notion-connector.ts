import { Client } from '@notionhq/client'
import { BaseConnector } from './base-connector'
import { BaseDocument, IngestionResult, DocumentMetadata } from '@/types/connectors.types'
import { prisma } from '@/lib/db'

export class NotionConnector extends BaseConnector {
  private client: Client

  constructor(config: { companyId: string; credentials: Record<string, string> }) {
    super(config)
    this.client = new Client({ auth: config.credentials.accessToken })
  }

  async validateCredentials(): Promise<boolean> {
    try {
      await this.client.users.me()
      return true
    } catch (error) {
      console.error('Notion auth validation failed:', error)
      return false
    }
  }

  async ingest(): Promise<IngestionResult> {
    const startTime = Date.now()
    const documents: BaseDocument[] = []
    const errors: string[] = []

    try {
      // Get all pages and databases the integration has access to
      const searchResult = await this.client.search({
        filter: {
          property: 'object',
          value: 'page',
        },
        page_size: 1000,
      })

      if (!searchResult.results) {
        throw new Error('No Notion pages found')
      }

      // Process each page in batches
      const pageDocs = await this.processBatch(
        searchResult.results,
        (page) => this.processPage(page as any),
        20 // Smaller batch for Notion API rate limits
      )

      documents.push(...pageDocs)

      // Update integration status
      await prisma.integration.update({
        where: {
          companyId_type: {
            companyId: this.config.companyId,
            type: 'NOTION',
          },
        },
        data: {
          status: 'ACTIVE',
          lastSync: new Date(),
        },
      })

      return {
        documents,
        totalProcessed: documents.length,
        errors,
        lastSync: new Date(),
      }
    } catch (error) {
      errors.push(`Notion ingestion failed: ${error}`)
      
      // Mark integration as error
      await prisma.integration.update({
        where: {
          companyId_type: {
            companyId: this.config.companyId,
            type: 'NOTION',
          },
        },
        data: {
          status: 'ERROR',
        },
      })

      throw error
    }
  }

  private async processPage(page: any): Promise<BaseDocument | null> {
    try {
      // Get page content
      const blocks = await this.client.blocks.children.list({
        block_id: page.id,
        page_size: 100,
      })

      // Extract text content from blocks
      const content = this.extractContentFromBlocks(blocks.results)
      
      if (!content.trim()) return null

      const metadata = this.extractNotionMetadata(page)
      const document = this.createDocument(
        page.id,
        content,
        metadata,
        'NOTION_PAGE',
        new Date(page.last_edited_time)
      )

      return document
    } catch (error) {
      console.error(`Error processing Notion page ${page.id}:`, error)
      return null
    }
  }

  private extractContentFromBlocks(blocks: any[]): string {
    const contentParts: string[] = []

    for (const block of blocks) {
      const text = this.extractTextFromBlock(block)
      if (text) {
        contentParts.push(text)
      }
    }

    return contentParts.join('\n\n')
  }

  private extractTextFromBlock(block: any): string | null {
    switch (block.type) {
      case 'paragraph':
        return this.extractRichText(block.paragraph.rich_text)
      
      case 'heading_1':
        return this.extractRichText(block.heading_1.rich_text)
      
      case 'heading_2':
        return this.extractRichText(block.heading_2.rich_text)
      
      case 'heading_3':
        return this.extractRichText(block.heading_3.rich_text)
      
      case 'bulleted_list_item':
        return `• ${this.extractRichText(block.bulleted_list_item.rich_text)}`
      
      case 'numbered_list_item':
        return `1. ${this.extractRichText(block.numbered_list_item.rich_text)}`
      
      case 'to_do':
        const text = this.extractRichText(block.to_do.rich_text)
        return block.to_do.checked ? `☑ ${text}` : `☐ ${text}`
      
      case 'toggle':
        return `🔽 ${this.extractRichText(block.toggle.rich_text)}`
      
      case 'quote':
        return `> ${this.extractRichText(block.quote.rich_text)}`
      
      case 'divider':
        return '---'
      
      default:
        return null
    }
  }

  private extractRichText(richText: any[]): string {
    if (!richText || !Array.isArray(richText)) return ''
    
    return richText
      .map((text) => {
        let content = text.plain_text || ''
        
        // Add formatting indicators
        if (text.annotations?.bold) content = `**${content}**`
        if (text.annotations?.italic) content = `*${content}*`
        if (text.annotations?.strikethrough) content = `~~${content}~~`
        if (text.annotations?.underline) content = `__${content}__`
        if (text.annotations?.code) content = `\`${content}\``
        
        return content
      })
      .join('')
  }

  private extractNotionMetadata(page: any): DocumentMetadata {
    const metadata: DocumentMetadata = {
      title: this.extractPageTitle(page),
      url: page.url,
      author: page.created_by?.id,
    }

    // Extract properties for additional metadata
    if (page.properties) {
      for (const [key, value] of Object.entries(page.properties)) {
        const prop = value as any
        
        // Extract department from properties
        if (key.toLowerCase().includes('department') && prop.type === 'select') {
          metadata.department = prop.select?.name
        }
        
        // Extract project from properties
        if (key.toLowerCase().includes('project') && prop.type === 'select') {
          metadata.project = prop.select?.name
        }
        
        // Extract tags from properties
        if (key.toLowerCase().includes('tag') && prop.type === 'multi_select') {
          metadata.tags = prop.multi_select?.map((tag: any) => tag.name) || []
        }
      }
    }

    // Infer department from title if not found in properties
    if (!metadata.department && metadata.title) {
      metadata.department = this.extractDepartmentFromTitle(metadata.title)
    }

    return metadata
  }

  private extractPageTitle(page: any): string {
    // Try to get title from properties
    const titleProp = page.properties?.title
    if (titleProp?.type === 'title' && titleProp.title?.length > 0) {
      return titleProp.title[0].plain_text
    }

    // Fallback to page ID
    return `Page ${page.id.slice(0, 8)}`
  }

  private extractDepartmentFromTitle(title: string): string {
    const departmentPatterns = {
      'marketing': /marketing|market|mkt/i,
      'engineering': /engineering|eng|dev|tech/i,
      'sales': /sales|revenue|growth/i,
      'product': /product|prod|pm/i,
      'hr': /hr|people|culture/i,
      'finance': /finance|fin|accounting/i,
    }

    for (const [dept, pattern] of Object.entries(departmentPatterns)) {
      if (pattern.test(title)) {
        return dept
      }
    }

    return 'general'
  }
}
