import { WebClient } from '@slack/web-api'
import { BaseConnector } from './base-connector'
import { BaseDocument, IngestionResult, DocumentMetadata } from '@/types/connectors.types'
import { prisma } from '@/lib/db'

export class SlackConnector extends BaseConnector {
  private client: WebClient

  constructor(config: { companyId: string; credentials: Record<string, string> }) {
    super(config)
    this.client = new WebClient(config.credentials.accessToken)
  }

  async validateCredentials(): Promise<boolean> {
    try {
      await this.client.auth.test()
      return true
    } catch (error) {
      console.error('Slack auth validation failed:', error)
      return false
    }
  }

  async ingest(): Promise<IngestionResult> {
    const startTime = Date.now()
    const documents: BaseDocument[] = []
    const errors: string[] = []

    try {
      // Get all channels the bot has access to
      const channelsResult = await this.client.conversations.list({
        types: 'public_channel,private_channel',
        limit: 1000,
      })

      if (!channelsResult.channels) {
        throw new Error('No channels found')
      }

      // Process each channel
      for (const channel of channelsResult.channels) {
        try {
          const channelDocs = await this.processChannel(channel.id!, channel.name!)
          documents.push(...channelDocs)
        } catch (error) {
          errors.push(`Channel ${channel.name}: ${error}`)
        }
      }

      // Update integration status
      await prisma.integration.update({
        where: {
          companyId_type: {
            companyId: this.config.companyId,
            type: 'SLACK',
          },
        },
        data: {
          status: 'ACTIVE',
          lastSync: new Date(),
        },
      })

      return {
        documents,
        totalProcessed: documents.length,
        errors,
        lastSync: new Date(),
      }
    } catch (error) {
      errors.push(`Slack ingestion failed: ${error}`)
      
      // Mark integration as error
      await prisma.integration.update({
        where: {
          companyId_type: {
            companyId: this.config.companyId,
            type: 'SLACK',
          },
        },
        data: {
          status: 'ERROR',
        },
      })

      throw error
    }
  }

  private async processChannel(channelId: string, channelName: string): Promise<BaseDocument[]> {
    const documents: BaseDocument[] = []
    const ninetyDaysAgo = Math.floor((Date.now() - 90 * 24 * 60 * 60 * 1000) / 1000)

    try {
      // Get messages from the last 90 days
      const result = await this.client.conversations.history({
        channel: channelId,
        oldest: ninetyDaysAgo.toString(),
        limit: 1000,
      })

      if (!result.messages) return documents

      // Process each message
      for (const message of result.messages) {
        if (message.subtype === 'bot_message' || !message.text) continue

        const metadata = this.extractSlackMetadata(message, channelName)
        const document = this.createDocument(
          message.ts!,
          message.text,
          metadata,
          'SLACK_MESSAGE',
          new Date(parseFloat(message.ts!) * 1000)
        )

        documents.push(document)

        // Process thread replies if this is a thread parent
        if (message.thread_ts && message.thread_ts === message.ts) {
          const threadDocs = await this.processThread(channelId, message.thread_ts, channelName)
          documents.push(...threadDocs)
        }
      }

      return documents
    } catch (error) {
      console.error(`Error processing channel ${channelName}:`, error)
      return documents
    }
  }

  private async processThread(channelId: string, threadTs: string, channelName: string): Promise<BaseDocument[]> {
    const documents: BaseDocument[] = []

    try {
      const replies = await this.client.conversations.replies({
        channel: channelId,
        ts: threadTs,
      })

      if (!replies.messages || replies.messages.length <= 1) return documents

      // Skip the parent message (already processed)
      const threadMessages = replies.messages.slice(1)

      for (const message of threadMessages) {
        if (message.subtype === 'bot_message' || !message.text) continue

        const metadata = this.extractSlackMetadata(message, channelName)
        const document = this.createDocument(
          message.ts!,
          message.text,
          metadata,
          'SLACK_MESSAGE',
          new Date(parseFloat(message.ts!) * 1000)
        )

        documents.push(document)
      }

      return documents
    } catch (error) {
      console.error(`Error processing thread ${threadTs}:`, error)
      return documents
    }
  }

  private extractSlackMetadata(message: any, channelName: string): DocumentMetadata {
    return {
      author: message.user,
      channelId: message.channel,
      threadId: message.thread_ts,
      tags: [channelName],
      department: this.extractDepartment(channelName),
    }
  }

  private extractDepartment(channelName: string): string {
    // Simple department extraction from channel names
    const departmentPatterns = {
      'marketing': /marketing|market|mkt/i,
      'engineering': /engineering|eng|dev|tech/i,
      'sales': /sales|revenue|growth/i,
      'product': /product|prod|pm/i,
      'hr': /hr|people|culture/i,
      'finance': /finance|fin|accounting/i,
    }

    for (const [dept, pattern] of Object.entries(departmentPatterns)) {
      if (pattern.test(channelName)) {
        return dept
      }
    }

    return 'general'
  }
}
