import { SearchQuery, SearchResult } from '@/types/connectors.types'
import { prisma } from '@/lib/db'

export class ContextGuardService {
  
  /**
   * Validates that search results belong to the user's company and context
   */
  async validateSearchContext(
    query: SearchQuery, 
    results: SearchResult[]
  ): Promise<{
    isValid: boolean
    violations: string[]
    filteredResults: SearchResult[]
  }> {
    const violations: string[] = []
    const filteredResults: SearchResult[] = []

    // Set company context for RLS
    await prisma.$executeRaw`SELECT set_company_context(${query.companyId}::uuid, ${query.userId}::uuid)`

    for (const result of results) {
      const validation = await this.validateSingleResult(query.companyId, result)
      
      if (validation.isValid) {
        filteredResults.push(result)
      } else {
        violations.push(...validation.violations)
      }
    }

    return {
      isValid: violations.length === 0,
      violations,
      filteredResults,
    }
  }

  private async validateSingleResult(
    companyId: string, 
    result: SearchResult
  ): Promise<{
    isValid: boolean
    violations: string[]
  }> {
    const violations: string[] = []

    try {
      // Verify the document exists and belongs to the company
      if (result.document.sourceType === 'SLACK_MESSAGE') {
        const message = await prisma.slackMessage.findUnique({
          where: { messageId: result.document.id },
        })

        if (!message) {
          violations.push(`Slack message ${result.document.id} not found`)
        } else if (message.companyId !== companyId) {
          violations.push(`Slack message ${result.document.id} belongs to different company`)
        }
      } else if (result.document.sourceType === 'NOTION_PAGE') {
        const page = await prisma.notionPage.findUnique({
          where: { pageId: result.document.id },
        })

        if (!page) {
          violations.push(`Notion page ${result.document.id} not found`)
        } else if (page.companyId !== companyId) {
          violations.push(`Notion page ${result.document.id} belongs to different company`)
        }
      }

      // Check for department access violations if user has restricted access
      await this.checkDepartmentAccess(companyId, result, violations)

    } catch (error) {
      violations.push(`Validation error for ${result.document.id}: ${error}`)
    }

    return {
      isValid: violations.length === 0,
      violations,
    }
  }

  private async checkDepartmentAccess(
    companyId: string, 
    result: SearchResult, 
    violations: string[]
  ): Promise<void> {
    // Get user's department access (could be extended for role-based access)
    const userAccess = await this.getUserDepartmentAccess(companyId)
    
    if (userAccess.departments.length > 0) {
      const resultDepartment = result.document.metadata.department
      
      if (resultDepartment && !userAccess.departments.includes(resultDepartment)) {
        violations.push(`User lacks access to department: ${resultDepartment}`)
      }
    }
  }

  private async getUserDepartmentAccess(companyId: string): Promise<{
    departments: string[]
    role: string
  }> {
    // This would be extended to implement role-based department access
    // For now, return full access
    return {
      departments: [],
      role: 'FULL_ACCESS',
    }
  }

  /**
   * Detects potential hallucination patterns in AI responses
   */
  async detectHallucination(
    query: string,
    answer: string,
    sources: SearchResult[]
  ): Promise<{
    isHallucination: boolean
    confidence: number
    warnings: string[]
  }> {
    const warnings: string[] = []
    let hallucinationScore = 0

    // Check 1: Answer contains information not in sources
    const sourceContent = sources.map(s => s.document.content.toLowerCase()).join(' ')
    const answerWords = answer.toLowerCase().split(/\s+/)
    
    const unknownWords = answerWords.filter(word => 
      word.length > 4 && 
      !sourceContent.includes(word) &&
      !this.isCommonWord(word)
    )

    if (unknownWords.length > answerWords.length * 0.1) {
      hallucinationScore += 0.3
      warnings.push('Response contains information not found in sources')
    }

    // Check 2: Answer is too generic when specific sources exist
    if (sources.length > 0 && this.isGenericResponse(answer)) {
      hallucinationScore += 0.2
      warnings.push('Generic response when specific information is available')
    }

    // Check 3: Answer claims certainty but sources are weak
    const avgSourceRelevance = sources.reduce((sum, s) => sum + s.relevanceScore, 0) / sources.length
    if (avgSourceRelevance < 0.6 && this.isConfidentResponse(answer)) {
      hallucinationScore += 0.4
      warnings.push('High confidence with low-quality sources')
    }

    // Check 4: Answer references specific details not in any source
    const specificDetails = this.extractSpecificDetails(answer)
    for (const detail of specificDetails) {
      const foundInSource = sources.some(source => 
        source.document.content.toLowerCase().includes(detail.toLowerCase())
      )
      
      if (!foundInSource) {
        hallucinationScore += 0.1
        warnings.push(`Specific detail "${detail}" not found in sources`)
      }
    }

    const isHallucination = hallucinationScore > 0.5
    const confidence = Math.max(0, 1 - hallucinationScore)

    return {
      isHallucination,
      confidence,
      warnings,
    }
  }

  private isCommonWord(word: string): boolean {
    const commonWords = [
      'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with',
      'by', 'from', 'up', 'about', 'into', 'through', 'during', 'before',
      'after', 'above', 'below', 'between', 'among', 'this', 'that', 'these',
      'those', 'have', 'has', 'had', 'was', 'were', 'been', 'being', 'are',
      'is', 'am', 'will', 'would', 'could', 'should', 'may', 'might', 'can',
      'said', 'told', 'asked', 'according', 'based', 'information', 'data',
    ]
    
    return commonWords.includes(word.toLowerCase())
  }

  private isGenericResponse(answer: string): boolean {
    const genericPhrases = [
      'no encontré información',
      'no tengo acceso',
      'no puedo responder',
      'información no disponible',
      'based on the context',
      'according to the sources',
    ]

    return genericPhrases.some(phrase => 
      answer.toLowerCase().includes(phrase.toLowerCase())
    )
  }

  private isConfidentResponse(answer: string): boolean {
    const confidentPhrases = [
      'definitivamente',
      'ciertamente',
      'absolutamente',
      'es claro que',
      'sin duda',
      'es obvio que',
    ]

    return confidentPhrases.some(phrase => 
      answer.toLowerCase().includes(phrase.toLowerCase())
    )
  }

  private extractSpecificDetails(answer: string): string[] {
    // Extract specific details like names, dates, numbers, quotes
    const details: string[] = []

    // Extract quoted text
    const quotes = answer.match(/"([^"]+)"/g)
    if (quotes) {
      details.push(...quotes.map(q => q.slice(1, -1)))
    }

    // Extract specific numbers with context
    const numbers = answer.match(/\b\d+(?:\.\d+)?\s*(?:%|dollars?|euros?|days?|weeks?|months?|years?)\b/gi)
    if (numbers) {
      details.push(...numbers)
    }

    // Extract dates
    const dates = answer.match(/\b\d{1,2}\/\d{1,2}\/\d{4}\b|\b\d{4}-\d{2}-\d{2}\b/g)
    if (dates) {
      details.push(...dates)
    }

    // Extract proper names (simplified)
    const properNames = answer.match(/\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b/g)
    if (properNames) {
      details.push(...properNames.filter(name => name.length > 3))
    }

    return details
  }

  /**
   * Adds safety context to AI prompts
   */
  buildSafetyPrompt(companyId: string): string {
    return `
SAFETY PROTOCOLS - CRITICAL:
1. Company Boundary: You are ONLY authorized to access information from company ID: ${companyId}
2. No Cross-Contamination: NEVER reference information from other companies
3. Source Verification: Only use information from the provided context
4. Uncertainty Handling: If information is incomplete, state limitations clearly
5. Confidentiality: Treat all information as confidential to this company

VIOLATION CONSEQUENCES:
- Cross-company data access = security breach
- Hallucinated information = user distrust
- Uncertain claims presented as facts = accuracy breach

RESPONSE REQUIREMENTS:
- Be precise and factual
- Cite specific sources when possible
- Acknowledge information gaps
- Maintain company context boundaries
    `
  }
}
