'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { 
  Users, 
  Building2, 
  Clock, 
  TrendingUp, 
  Activity, 
  ArrowUp,
  ArrowDown,
  BarChart3,
  PieChart,
  Calendar
} from 'lucide-react'

interface GrowthStats {
  totalUsers: number
  totalCompanies: number
  activeCompanies: number
  avgTimeSaved: number
  userGrowth: {
    thisWeek: number
    lastWeek: number
    trend: 'up' | 'down'
  }
  companyGrowth: {
    thisWeek: number
    lastWeek: number
    trend: 'up' | 'down'
  }
  searchStats: {
    totalQueries: number
    avgResponseTime: number
    avgConfidence: number
  }
  topQueries: Array<{
    query: string
    count: number
    growth: number
  }>
  departmentUsage: Array<{
    department: string
    usage: number
    queries: number
  }>
}

export default function AdminDashboard() {
  const { data: session } = useSession()
  const [stats, setStats] = useState<GrowthStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d')

  useEffect(() => {
    if (session?.user?.role === 'ADMIN') {
      fetchStats()
    }
  }, [session, timeRange])

  const fetchStats = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/admin/stats?range=${timeRange}`)
      if (response.ok) {
        const data = await response.json()
        setStats(data)
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error)
    } finally {
      setLoading(false)
    }
  }

  if (!session || session.user?.role !== 'ADMIN') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-indigo-50 dark:from-violet-950 dark:via-slate-900 dark:to-indigo-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="h-8 w-8 text-red-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            Acceso Restringido
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Esta página está disponible solo para administradores
          </p>
        </div>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-indigo-50 dark:from-violet-950 dark:via-slate-900 dark:to-indigo-950 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="premium-card rounded-2xl p-6">
                <div className="h-4 w-24 bg-muted rounded-lg skeleton-shimmer mb-4" />
                <div className="h-8 w-16 bg-muted rounded-lg skeleton-shimmer" />
              </div>
            ))}
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="premium-card rounded-2xl p-6">
              <div className="h-6 w-32 bg-muted rounded-lg skeleton-shimmer mb-4" />
              <div className="space-y-3">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="h-4 w-48 bg-muted rounded-lg skeleton-shimmer" />
                    <div className="h-4 w-16 bg-muted rounded-lg skeleton-shimmer" />
                  </div>
                ))}
              </div>
            </div>
            
            <div className="premium-card rounded-2xl p-6">
              <div className="h-6 w-32 bg-muted rounded-lg skeleton-shimmer mb-4" />
              <div className="h-48 bg-muted/20 rounded-xl skeleton-shimmer" />
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!stats) return null

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`
    return num.toString()
  }

  const formatTime = (minutes: number): string => {
    if (minutes >= 60) {
      const hours = Math.floor(minutes / 60)
      const mins = minutes % 60
      return `${hours}h ${mins}m`
    }
    return `${minutes}m`
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-indigo-50 dark:from-violet-950 dark:via-slate-900 dark:to-indigo-950 p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-premium mb-2">
              Dashboard de Crecimiento
            </h1>
            <p className="text-muted-foreground">
              Métricas en tiempo real del negocio
            </p>
          </div>
          
          <div className="flex items-center space-x-2">
            {['7d', '30d', '90d'].map((range) => (
              <Button
                key={range}
                variant={timeRange === range ? 'default' : 'outline'}
                size="sm"
                onClick={() => setTimeRange(range as any)}
              >
                {range === '7d' ? '7 días' : range === '30d' ? '30 días' : '90 días'}
              </Button>
            ))}
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="premium-card rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
              <div className={cn(
                "flex items-center text-sm",
                stats.userGrowth.trend === 'up' ? 'text-green-600' : 'text-red-600'
              )}>
                {stats.userGrowth.trend === 'up' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />}
                {Math.abs(((stats.userGrowth.thisWeek - stats.userGrowth.lastWeek) / stats.userGrowth.lastWeek * 100)).toFixed(1)}%
              </div>
            </div>
            <div>
              <div className="text-2xl font-bold text-premium">{formatNumber(stats.totalUsers)}</div>
              <div className="text-sm text-muted-foreground">Usuarios Totales</div>
            </div>
          </div>

          <div className="premium-card rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Building2 className="h-6 w-6 text-green-600" />
              </div>
              <div className={cn(
                "flex items-center text-sm",
                stats.companyGrowth.trend === 'up' ? 'text-green-600' : 'text-red-600'
              )}>
                {stats.companyGrowth.trend === 'up' ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />}
                {Math.abs(((stats.companyGrowth.thisWeek - stats.companyGrowth.lastWeek) / stats.companyGrowth.lastWeek * 100)).toFixed(1)}%
              </div>
            </div>
            <div>
              <div className="text-2xl font-bold text-premium">{stats.totalCompanies}</div>
              <div className="text-sm text-muted-foreground">Empresas ({stats.activeCompanies} activas)</div>
            </div>
          </div>

          <div className="premium-card rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-violet-100 rounded-lg flex items-center justify-center">
                <Clock className="h-6 w-6 text-violet-600" />
              </div>
              <div className="flex items-center text-sm text-green-600">
                <ArrowUp className="h-4 w-4" />
                12%
              </div>
            </div>
            <div>
              <div className="text-2xl font-bold text-premium">{formatTime(stats.avgTimeSaved)}</div>
              <div className="text-sm text-muted-foreground">Ahorro Promedio</div>
            </div>
          </div>

          <div className="premium-card rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <Activity className="h-6 w-6 text-orange-600" />
              </div>
              <div className="flex items-center text-sm text-green-600">
                <ArrowUp className="h-4 w-4" />
                8%
              </div>
            </div>
            <div>
              <div className="text-2xl font-bold text-premium">{formatNumber(stats.searchStats.totalQueries)}</div>
              <div className="text-sm text-muted-foreground">Búsquedas Totales</div>
            </div>
          </div>
        </div>

        {/* Detailed Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Top Queries */}
          <div className="premium-card rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-premium flex items-center">
                <BarChart3 className="h-5 w-5 mr-2 text-violet-600" />
                Queries Populares
              </h3>
            </div>
            
            <div className="space-y-4">
              {stats.topQueries.slice(0, 5).map((query, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
                  <div className="flex-1">
                    <div className="font-medium text-premium truncate">{query.query}</div>
                    <div className="text-sm text-muted-foreground">{formatNumber(query.count)} búsquedas</div>
                  </div>
                  <div className={cn(
                    "flex items-center text-sm",
                    query.growth > 0 ? 'text-green-600' : 'text-red-600'
                  )}>
                    {query.growth > 0 ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />}
                    {Math.abs(query.growth)}%
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Department Usage */}
          <div className="premium-card rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-premium flex items-center">
                <PieChart className="h-5 w-5 mr-2 text-violet-600" />
                Uso por Departamento
              </h3>
            </div>
            
            <div className="space-y-4">
              {stats.departmentUsage.map((dept, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-premium">{dept.department}</span>
                    <span className="text-sm text-muted-foreground">{dept.usage}%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-violet-600 to-indigo-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${dept.usage}%` }}
                    />
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {formatNumber(dept.queries)} búsquedas
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Performance Metrics */}
        <div className="premium-card rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-premium flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-violet-600" />
              Métricas de Rendimiento
            </h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">
                {stats.searchStats.avgResponseTime}ms
              </div>
              <div className="text-sm text-muted-foreground">Tiempo de Respuesta</div>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">
                {(stats.searchStats.avgConfidence * 100).toFixed(1)}%
              </div>
              <div className="text-sm text-muted-foreground">Confianza Promedio</div>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-violet-600">
                {formatTime(stats.avgTimeSaved)}
              </div>
              <div className="text-sm text-muted-foreground">Ahorro por Usuario</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
