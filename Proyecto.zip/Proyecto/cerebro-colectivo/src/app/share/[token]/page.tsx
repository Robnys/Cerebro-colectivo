'use client'

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { InsightCard } from '@/components/search/insight-card'
import { KnowledgeGraph } from '@/components/search/knowledge-graph'
import { cn } from '@/lib/utils'
import { ArrowLeft, Users, Lock, Sparkles, CheckCircle } from 'lucide-react'

interface SharedInsightData {
  query: string
  answer: string
  views: number
  conversions: number
  createdAt: string
  expiresAt: string
  sharedBy: {
    name: string
    company: string
  }
}

export default function SharedInsightPage() {
  const params = useParams()
  const [insight, setInsight] = useState<SharedInsightData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showSignupPrompt, setShowSignupPrompt] = useState(false)

  useEffect(() => {
    const loadInsight = async () => {
      try {
        const response = await fetch(`/api/share/${params.token}`)
        
        if (!response.ok) {
          if (response.status === 404) {
            setError('Este insight compartido no existe o ha expirado')
          } else {
            setError('Error al cargar el insight compartido')
          }
          return
        }

        const data = await response.json()
        setInsight(data)
      } catch (err) {
        setError('Error de conexión. Intenta nuevamente.')
      } finally {
        setLoading(false)
      }
    }

    if (params.token) {
      loadInsight()
    }
  }, [params.token])

  const handleTryFullAccess = async () => {
    setShowSignupPrompt(true)
    
    // Track conversion
    try {
      await fetch(`/api/share/${params.token}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'convert' })
      })
    } catch (error) {
      console.error('Failed to track conversion:', error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-indigo-50 dark:from-violet-950 dark:via-slate-900 dark:to-indigo-950">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            {/* Header skeleton */}
            <div className="mb-8">
              <div className="h-8 w-32 bg-muted rounded-lg skeleton-shimmer mb-4" />
              <div className="h-12 w-64 bg-muted rounded-lg skeleton-shimmer" />
            </div>
            
            {/* Main content skeleton */}
            <div className="premium-card rounded-2xl p-6 space-y-4">
              <div className="h-6 w-3/4 bg-muted rounded-lg skeleton-shimmer" />
              <div className="h-4 w-full bg-muted rounded-lg skeleton-shimmer" />
              <div className="h-4 w-5/6 bg-muted rounded-lg skeleton-shimmer" />
              <div className="h-4 w-4/5 bg-muted rounded-lg skeleton-shimmer" />
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-indigo-50 dark:from-violet-950 dark:via-slate-900 dark:to-indigo-950 flex items-center justify-center">
        <div className="text-center">
          <div className="mb-6">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto">
              <Lock className="h-8 w-8 text-red-600" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            Insight No Disponible
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            {error}
          </p>
          <Button onClick={() => window.history.back()} variant="outline">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver
          </Button>
        </div>
      </div>
    )
  }

  if (!insight) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-indigo-50 dark:from-violet-950 dark:via-slate-900 dark:to-indigo-950">
      {/* Header */}
      <div className="border-b border-border bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-violet-600 to-indigo-600 rounded-lg flex items-center justify-center">
                  <Sparkles className="h-4 w-4 text-white" />
                </div>
                <span className="font-semibold text-premium">Cerebro Colectivo</span>
              </div>
              
              <div className="hidden sm:flex items-center space-x-2 text-sm text-muted-foreground">
                <span>Compartido por</span>
                <span className="font-medium">{insight.sharedBy.name}</span>
                <span>•</span>
                <span>{insight.sharedBy.company}</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className="hidden sm:flex items-center space-x-1 text-sm text-muted-foreground">
                <Users className="h-4 w-4" />
                <span>{insight.views} vistas</span>
              </div>
              
              <Button onClick={() => window.history.back()} variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Preview Banner */}
          <div className="premium-card rounded-2xl p-6 bg-gradient-to-r from-violet-600 to-indigo-600 text-white">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold mb-2">Este es un insight compartido</h2>
                <p className="text-violet-100">
                  Obtén acceso completo a Cerebro Colectivo para buscar en todo tu conocimiento empresarial
                </p>
              </div>
              
              <div className="hidden md:block">
                <Button 
                  onClick={handleTryFullAccess}
                  variant="secondary"
                  className="bg-white text-violet-600 hover:bg-violet-50"
                >
                  Probar Gratis
                </Button>
              </div>
            </div>
          </div>

          {/* Insight Card */}
          <InsightCard
            query={insight.query}
            answer={insight.answer}
            sources={[]} // Sources not shown in public preview
            confidence={0.8}
            responseTime={1200}
            onShare={() => {}}
            className="animate-fade-in-up"
          />

          {/* Knowledge Graph Preview */}
          <div className="animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
            <KnowledgeGraph
              sources={[]} // Mock sources for visualization
              query={insight.query}
              className="opacity-75"
            />
          </div>

          {/* Mobile CTA */}
          <div className="md:hidden">
            <Button 
              onClick={handleTryFullAccess}
              className="w-full premium"
              size="lg"
            >
              Obtén Acceso Completo
            </Button>
          </div>

          {/* Features Preview */}
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: Search,
                title: "Búsqueda Inteligente",
                description: "Encuentra información instantáneamente en Slack, Notion y más"
              },
              {
                icon: Network,
                title: "Conexiones de Conocimiento",
                description: "Visualiza cómo la IA conecta información de diferentes fuentes"
              },
              {
                icon: TrendingUp,
                title: "Insights Compartibles",
                description: "Comparte descubrimientos valiosos con tu equipo"
              }
            ].map((feature, index) => (
              <div key={index} className="premium-card rounded-xl p-6 text-center animate-fade-in-up" 
                   style={{ animationDelay: `${0.3 + index * 0.1}s` }}>
                <div className="w-12 h-12 bg-violet-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="h-6 w-6 text-violet-600" />
                </div>
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Signup Modal */}
      {showSignupPrompt && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="premium-card rounded-2xl p-8 max-w-md w-full animate-fade-in-up">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              
              <h3 className="text-2xl font-bold mb-2">Desbloquea Todo el Poder</h3>
              <p className="text-muted-foreground mb-6">
                Únete a {insight.sharedBy.company} y otros equipos que usan Cerebro Colectivo para encontrar conocimiento instantáneamente.
              </p>
              
              <div className="space-y-3">
                <Button className="w-full premium">
                  Comenzar Gratis
                </Button>
                
                <Button variant="outline" className="w-full" onClick={() => setShowSignupPrompt(false)}>
                  Ahora no
                </Button>
              </div>
              
              <p className="text-xs text-muted-foreground mt-4">
                3 búsquedas gratis • Sin tarjeta de crédito • Cancela cuando quieras
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// Add missing imports
import { Search, Network, TrendingUp } from 'lucide-react'
