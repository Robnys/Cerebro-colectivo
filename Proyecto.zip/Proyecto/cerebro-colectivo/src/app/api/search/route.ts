import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { SearchService } from '@/services/search.service'
import { z } from 'zod'

const searchSchema = z.object({
  query: z.string().min(1).max(500),
  filters: z.object({
    sourceType: z.array(z.enum(['SLACK_MESSAGE', 'NOTION_PAGE'])).optional(),
    dateRange: z.object({
      start: z.string().datetime(),
      end: z.string().datetime(),
    }).optional(),
    department: z.array(z.string()).optional(),
    author: z.array(z.string()).optional(),
  }).optional(),
})

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.companyId || !session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { query, filters } = searchSchema.parse(body)

    const searchService = new SearchService()
    const result = await searchService.search({
      text: query,
      userId: session.user.id,
      companyId: session.user.companyId,
      filters,
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error('Search API error:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid request format', details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { error: 'Search failed' },
      { status: 500 }
    )
  }
}
