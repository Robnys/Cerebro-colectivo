import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { z } from 'zod'
import { generateShareToken } from '@/lib/utils'

const shareSchema = z.object({
  query: z.string().min(1),
  answer: z.string().min(1),
  sources: z.array(z.any()).optional(),
})

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.companyId || !session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { query, answer, sources } = shareSchema.parse(body)

    // Generate unique share token
    const shareToken = generateShareToken()

    // Create shared insight record
    const sharedInsight = await prisma.sharedInsight.create({
      data: {
        userId: session.user.id,
        query,
        answer,
        shareToken,
        isActive: true,
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
      },
    })

    // Return share URL
    const shareUrl = `${process.env.NEXTAUTH_URL}/share/${shareToken}`

    return NextResponse.json({
      success: true,
      shareUrl,
      shareToken,
      expiresAt: sharedInsight.expiresAt,
    })
  } catch (error) {
    console.error('Share creation error:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid request format', details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { error: 'Failed to create share' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.companyId || !session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    // Get user's shared insights
    const sharedInsights = await prisma.sharedInsight.findMany({
      where: {
        userId: session.user.id,
        isActive: true,
      },
      include: {
        user: {
          select: {
            email: true,
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      },
      take: 50,
    })

    return NextResponse.json({
      sharedInsights: sharedInsights.map(insight => ({
        id: insight.id,
        query: insight.query,
        answer: insight.answer.slice(0, 200) + '...',
        shareUrl: `${process.env.NEXTAUTH_URL}/share/${insight.shareToken}`,
        views: insight.views,
        conversions: insight.conversions,
        createdAt: insight.createdAt,
        expiresAt: insight.expiresAt,
      }))
    })
  } catch (error) {
    console.error('Share list error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch shared insights' },
      { status: 500 }
    )
  }
}
