import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { token: string } }
) {
  try {
    const { token } = params

    // Find shared insight by token
    const sharedInsight = await prisma.sharedInsight.findUnique({
      where: { 
        shareToken: token,
        isActive: true,
      },
      include: {
        user: {
          include: {
            company: true
          }
        }
      }
    })

    if (!sharedInsight) {
      return NextResponse.json(
        { error: 'Shared insight not found or expired' },
        { status: 404 }
      )
    }

    // Increment view count
    await prisma.sharedInsight.update({
      where: { id: sharedInsight.id },
      data: {
        views: {
          increment: 1
        }
      }
    })

    // Return the shared insight data
    return NextResponse.json({
      query: sharedInsight.query,
      answer: sharedInsight.answer,
      views: sharedInsight.views,
      conversions: sharedInsight.conversions,
      createdAt: sharedInsight.createdAt,
      expiresAt: sharedInsight.expiresAt,
      sharedBy: {
        name: sharedInsight.user.email.split('@')[0],
        company: sharedInsight.user.company.name
      }
    })

  } catch (error) {
    console.error('Share API error:', error)
    return NextResponse.json(
      { error: 'Failed to load shared insight' },
      { status: 500 }
    )
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { token: string } }
) {
  try {
    const { token } = params
    const body = await request.json()
    const { action } = body

    if (action === 'convert') {
      // Increment conversion count when user tries to access full features
      const sharedInsight = await prisma.sharedInsight.update({
        where: { shareToken: token },
        data: {
          conversions: {
            increment: 1
          }
        }
      })

      return NextResponse.json({
        success: true,
        conversions: sharedInsight.conversions
      })
    }

    return NextResponse.json(
      { error: 'Invalid action' },
      { status: 400 }
    )

  } catch (error) {
    console.error('Share conversion error:', error)
    return NextResponse.json(
      { error: 'Failed to process conversion' },
      { status: 500 }
    )
  }
}
