import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { SlackConnector } from '@/services/connectors/slack-connector'
import { NotionConnector } from '@/services/connectors/notion-connector'
import { VectorizationService } from '@/services/vectorization.service'
import { prisma } from '@/lib/db'
import { z } from 'zod'

const syncSchema = z.object({
  integrationType: z.enum(['SLACK', 'NOTION']),
})

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.companyId || !session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { integrationType } = syncSchema.parse(body)

    // Get integration credentials
    const integration = await prisma.integration.findFirst({
      where: {
        companyId: session.user.companyId,
        type: integrationType,
        status: 'ACTIVE',
      },
    })

    if (!integration) {
      return NextResponse.json(
        { error: 'Integration not found or inactive' },
        { status: 404 }
      )
    }

    // Set company context for RLS
    await prisma.$executeRaw`SELECT set_company_context(${session.user.companyId}::uuid, ${session.user.id}::uuid)`

    let documents: any[] = []

    // Step 1: Ingest data based on integration type
    if (integrationType === 'SLACK') {
      const slackConnector = new SlackConnector({
        companyId: session.user.companyId,
        credentials: integration.credentials as any,
      })
      
      const result = await slackConnector.ingest()
      documents = result.documents

      // Store messages in database
      await storeSlackMessages(documents, session.user.companyId)
    } else if (integrationType === 'NOTION') {
      const notionConnector = new NotionConnector({
        companyId: session.user.companyId,
        credentials: integration.credentials as any,
      })
      
      const result = await notionConnector.ingest()
      documents = result.documents

      // Store pages in database
      await storeNotionPages(documents, session.user.companyId)
    }

    // Step 2: Vectorize documents
    const vectorizationService = new VectorizationService()
    await vectorizationService.vectorizeDocuments(documents)

    return NextResponse.json({
      success: true,
      documentsProcessed: documents.length,
      integrationType,
    })
  } catch (error) {
    console.error('Integration sync error:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid request format', details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { error: 'Sync failed' },
      { status: 500 }
    )
  }
}

async function storeSlackMessages(documents: any[], companyId: string): Promise<void> {
  const operations = documents.map(doc =>
    prisma.slackMessage.upsert({
      where: { messageId: doc.id },
      update: {
        text: doc.content,
        timestamp: doc.timestamp,
        replyCount: doc.metadata.replyCount || 0,
        reactionCount: doc.metadata.reactionCount || 0,
      },
      create: {
        messageId: doc.id,
        companyId,
        channelId: doc.metadata.channelId || '',
        userId: doc.metadata.author || '',
        text: doc.content,
        timestamp: doc.timestamp,
        threadId: doc.metadata.threadId,
        replyCount: doc.metadata.replyCount || 0,
        reactionCount: doc.metadata.reactionCount || 0,
      },
    })
  )

  await Promise.allSettled(operations)
}

async function storeNotionPages(documents: any[], companyId: string): Promise<void> {
  const operations = documents.map(doc =>
    prisma.notionPage.upsert({
      where: { pageId: doc.id },
      update: {
        title: doc.metadata.title || '',
        content: doc.content,
        lastModified: doc.timestamp,
        url: doc.metadata.url,
        createdBy: doc.metadata.author,
      },
      create: {
        pageId: doc.id,
        companyId,
        title: doc.metadata.title || '',
        content: doc.content,
        lastModified: doc.timestamp,
        url: doc.metadata.url,
        createdBy: doc.metadata.author,
      },
    })
  )

  await Promise.allSettled(operations)
}
