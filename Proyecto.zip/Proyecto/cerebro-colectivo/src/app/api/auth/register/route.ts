import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { z } from 'zod'

const registerSchema = z.object({
  email: z.string().email(),
  companyName: z.string().min(2),
  companyDomain: z.string().optional(),
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, companyName, companyDomain } = registerSchema.parse(body)

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email },
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'User already exists' },
        { status: 400 }
      )
    }

    // Create or find company
    let company
    if (companyDomain) {
      company = await prisma.company.findUnique({
        where: { domain: companyDomain },
      })
    }

    if (!company) {
      company = await prisma.company.create({
        data: {
          name: companyName,
          domain: companyDomain,
        },
      })
    }

    // Create user (will be completed by OAuth flow)
    const user = await prisma.user.create({
      data: {
        email,
        companyId: company.id,
        role: 'MEMBER',
      },
    })

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        companyId: company.id,
      },
    })
  } catch (error) {
    console.error('Registration error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
