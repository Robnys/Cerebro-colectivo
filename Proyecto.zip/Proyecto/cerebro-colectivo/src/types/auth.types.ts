import { User, Company, UserRole } from '@prisma/client'

export interface AuthUser extends User {
  company: Company
}

export interface AuthSession {
  user: {
    id: string
    email: string
    name?: string | null
    image?: string | null
    companyId: string
    company: Company
    role: UserRole
  }
  expires: string
}

export interface RegisterRequest {
  email: string
  companyName: string
  companyDomain?: string
}

export interface AuthResponse {
  success: boolean
  user?: {
    id: string
    email: string
    companyId: string
  }
  error?: string
}
