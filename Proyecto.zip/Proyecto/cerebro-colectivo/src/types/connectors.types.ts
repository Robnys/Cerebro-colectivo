import { SourceType } from '@prisma/client'

export interface BaseDocument {
  id: string
  content: string
  metadata: DocumentMetadata
  sourceType: SourceType
  timestamp: Date
}

export interface DocumentMetadata {
  title?: string
  author?: string
  channelId?: string
  threadId?: string
  url?: string
  tags?: string[]
  department?: string
  project?: string
}

export interface ConnectorConfig {
  companyId: string
  credentials: Record<string, string>
}

export interface IngestionResult {
  documents: BaseDocument[]
  totalProcessed: number
  errors: string[]
  lastSync: Date
}

export interface VectorEmbedding {
  id: string
  sourceType: SourceType
  sourceId: string
  embedding: number[]
  metadata: DocumentMetadata
}

export interface SearchResult {
  document: BaseDocument
  relevanceScore: number
  position: number
}

export interface SearchQuery {
  text: string
  userId: string
  companyId: string
  filters?: SearchFilters
}

export interface SearchFilters {
  sourceType?: SourceType[]
  dateRange?: {
    start: Date
    end: Date
  }
  department?: string[]
  author?: string[]
}

export interface RAGResponse {
  answer: string
  sources: SearchResult[]
  confidence: number
  queryId: string
  responseTime: number
}
